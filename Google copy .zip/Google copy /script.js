let body = document.getElementsByTagName("body").innerHTML
let p = document.getElementsByTagName("p").innerHTML
let a = document.getElementsByTagName('a').innerHTML
let options = document.getElementsByClassName("options").innerText
function darkchange(){

    document.body.style.backgroundColor='black'
    document.body.style.color='white'
    
    
    
}
function whitechange(){
    document.body.style.backgroundColor='white'
    document.body.style.color = 'black'
  
    


    
}
